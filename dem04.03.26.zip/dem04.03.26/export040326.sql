-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 91.222.238.6    Database: dem04.03.26
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Order`
--

DROP TABLE IF EXISTS `Order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Order` (
  `idOrder` int NOT NULL AUTO_INCREMENT,
  `date_order` date NOT NULL,
  `date_end_order` date NOT NULL,
  `id_adress` int NOT NULL,
  `id_client` int DEFAULT NULL,
  `cod` int NOT NULL,
  `id_status` int NOT NULL,
  PRIMARY KEY (`idOrder`),
  KEY `id_status_idx` (`id_status`),
  KEY `id_adres_idx` (`id_adress`),
  KEY `id_client_idx` (`id_client`),
  CONSTRAINT `id_adres` FOREIGN KEY (`id_adress`) REFERENCES `adress` (`idadress`),
  CONSTRAINT `id_client` FOREIGN KEY (`id_client`) REFERENCES `user` (`iduser`),
  CONSTRAINT `id_status` FOREIGN KEY (`id_status`) REFERENCES `Status_order` (`idStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Order`
--

LOCK TABLES `Order` WRITE;
/*!40000 ALTER TABLE `Order` DISABLE KEYS */;
INSERT INTO `Order` VALUES (1,'2022-05-19','2022-05-25',1,NULL,921,2),(2,'2022-05-20','2022-05-26',36,NULL,922,1),(3,'2022-05-21','2022-05-27',2,7,923,1),(4,'2022-05-23','2022-05-29',11,9,924,1),(5,'2022-05-23','2022-05-29',2,NULL,925,2),(6,'2022-05-24','2022-05-30',34,NULL,926,2),(7,'2022-05-25','2022-05-31',3,8,927,1),(8,'2022-05-27','2022-06-02',19,NULL,928,1),(9,'2022-05-27','2022-06-02',5,10,929,1),(10,'2022-05-28','2022-06-03',25,NULL,930,2);
/*!40000 ALTER TABLE `Order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Order_items`
--

DROP TABLE IF EXISTS `Order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Order_items` (
  `idOrder_items` int NOT NULL AUTO_INCREMENT,
  `id_Order` int NOT NULL,
  `id_tovar` int NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`idOrder_items`),
  KEY `ID_ORDER_idx` (`id_Order`),
  KEY `ID_TOVAR_idx` (`id_tovar`),
  CONSTRAINT `ID_ORDER` FOREIGN KEY (`id_Order`) REFERENCES `Order` (`idOrder`),
  CONSTRAINT `ID_TOVAR` FOREIGN KEY (`id_tovar`) REFERENCES `tovar` (`id_tov`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Order_items`
--

LOCK TABLES `Order_items` WRITE;
/*!40000 ALTER TABLE `Order_items` DISABLE KEYS */;
INSERT INTO `Order_items` VALUES (1,1,1,1),(2,2,4,2),(3,3,8,1),(4,4,10,5),(5,5,12,2),(6,6,13,1),(7,7,17,4),(8,8,17,2),(9,9,24,1),(10,10,28,4),(11,1,2,1),(12,2,5,2),(13,3,9,1),(14,4,11,5),(15,5,13,2),(16,6,16,1),(17,7,18,2),(18,8,20,1),(19,9,25,1),(20,10,29,5);
/*!40000 ALTER TABLE `Order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role` (
  `idRole` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idRole`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (1,'Администратор'),(2,'Менеджер'),(3,'Клиент');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Status_order`
--

DROP TABLE IF EXISTS `Status_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Status_order` (
  `idStatus` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Status_order`
--

LOCK TABLES `Status_order` WRITE;
/*!40000 ALTER TABLE `Status_order` DISABLE KEYS */;
INSERT INTO `Status_order` VALUES (1,'Новый'),(2,'Завершен');
/*!40000 ALTER TABLE `Status_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adress`
--

DROP TABLE IF EXISTS `adress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adress` (
  `idadress` int NOT NULL AUTO_INCREMENT,
  `index` bigint NOT NULL,
  `city` varchar(45) NOT NULL,
  `stret` varchar(45) NOT NULL,
  `number_house` int NOT NULL,
  PRIMARY KEY (`idadress`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adress`
--

LOCK TABLES `adress` WRITE;
/*!40000 ALTER TABLE `adress` DISABLE KEYS */;
INSERT INTO `adress` VALUES (1,344288,'г. Михайловка','ул. Чехова',1),(2,614164,'г.Михайловка','  ул. Степная',30),(3,394242,'г. Михайловка','ул. Коммунистическая',43),(4,660540,'г. Михайловка','ул. Солнечная',25),(5,125837,'г. Михайловка','ул. Шоссейная',40),(6,125703,'г. Михайловка','ул. Партизанская',49),(7,625283,'г. Михайловка','ул. Победы',46),(8,614611,'г. Михайловка','ул. Молодежная',50),(9,454311,'г.Михайловка','ул. Новая',19),(10,660007,'г.Михайловка','ул. Октябрьская',19),(11,603036,'г. Михайловка','ул. Садовая',4),(12,450983,'г.Михайловка','ул. Комсомольская',26),(13,394782,'г. Михайловка','ул. Чехова',3),(14,603002,'г. Михайловка','ул. Дзержинского',28),(15,450558,'г. Михайловка','ул. Набережная',30),(16,394060,'г.Михайловка','ул. Фрунзе',43),(17,410661,'г. Михайловка','ул. Школьная',50),(18,625590,'г. Михайловка','ул. Коммунистическая',20),(19,625683,'г. Михайловка','ул. 8 Марта',33),(20,400562,'г. Михайловка','ул. Зеленая',32),(21,614510,'г. Михайловка','ул. Маяковского',47),(22,410542,'г. Михайловка','ул. Светлая',46),(23,620839,'г. Михайловка','ул. Цветочная',8),(24,443890,'г. Михайловка','ул. Коммунистическая',1),(25,603379,'г. Михайловка','ул. Спортивная',46),(26,603721,'г. Михайловка','ул. Гоголя',41),(27,410172,'г. Михайловка','ул. Северная',13),(28,420151,'г. Михайловка','ул. Вишневая',32),(29,125061,'г. Михайловка','ул. Подгорная',8),(30,630370,'г. Михайловка','ул. Шоссейная',24),(31,614753,'г. Михайловка','ул. Полевая',35),(32,426030,'г. Михайловка','ул. Маяковского',44),(33,450375,'г. Михайловка','ул. Клубная',44),(34,625560,'г. Михайловка','ул. Некрасова',12),(35,630201,'г. Михайловка','ул. Комсомольская',17),(36,190949,'г. Михайловка','ул. Мичурина',26);
/*!40000 ALTER TABLE `adress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `idcategory` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idcategory`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Серьги'),(2,'Подвеска'),(3,'Ожерелье'),(4,'Брошь'),(5,'Кольцо'),(6,'Колье'),(7,'Браслет');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturer` (
  `idmanufacturer` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idmanufacturer`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturer`
--

LOCK TABLES `manufacturer` WRITE;
/*!40000 ALTER TABLE `manufacturer` DISABLE KEYS */;
INSERT INTO `manufacturer` VALUES (1,'SunLight'),(2,'Sokolov');
/*!40000 ALTER TABLE `manufacturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `idsupplier` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`idsupplier`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'ЮвелирКарат'),(2,'ЮвелирТорг');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tovar`
--

DROP TABLE IF EXISTS `tovar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tovar` (
  `id_tov` int NOT NULL AUTO_INCREMENT,
  `article` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `unit` varchar(45) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `sizeorder` int NOT NULL,
  `manuf_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `category_id` int NOT NULL,
  `salepercent` int NOT NULL,
  `quantity` int NOT NULL,
  `discription` varchar(590) NOT NULL,
  `image` longblob,
  PRIMARY KEY (`id_tov`),
  KEY `id_man_idx` (`manuf_id`),
  KEY `id_suppl_idx` (`supplier_id`),
  KEY `id_cat_idx` (`category_id`),
  CONSTRAINT `id_cat` FOREIGN KEY (`category_id`) REFERENCES `category` (`idcategory`),
  CONSTRAINT `id_man` FOREIGN KEY (`manuf_id`) REFERENCES `manufacturer` (`idmanufacturer`),
  CONSTRAINT `id_suppl` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`idsupplier`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tovar`
--

LOCK TABLES `tovar` WRITE;
/*!40000 ALTER TABLE `tovar` DISABLE KEYS */;
INSERT INTO `tovar` VALUES (1,'А112Т4','Серьги','шт.',590.00,30,1,1,1,3,6,'Серьги серебряные в позолоте продёвки на цепочке \"Звезда\"',_binary 'А112Т4.png'),(2,'G843Y6','Подвеска','шт.',240.00,25,2,2,2,3,6,'Подвеска серебряная с фианитами 2138729/9 Ювелир Карат',_binary 'G843Y6.jpg'),(3,'G836H6','Подвеска','шт.',140.00,10,2,2,2,2,16,'Подвеска серебряная в позолоте с фианитами 2139189/9п Ювелир Карат',_binary 'G836H6.jpg'),(4,'S648N6','Серьги','шт.',990.00,5,1,1,1,4,5,'Серьги \"Бабочки\" в позолоте',_binary 'S648N6.png'),(5,'D493Y7','Ожерелье','шт.',79000.00,30,1,2,3,3,2,'Ожерелье Cordelia (муассанит, 11шт, 3,5мм, круг, BS Regular, 40см',_binary 'D493Y7.jpg'),(6,'D936R6','Серьги','шт.',890.00,30,2,1,1,3,6,'Серьги со стразами Swarovski 2129919/96П Ювелир Карат',_binary 'D936R6.jpg'),(7,'S395J7','Серьги','шт.',7000.00,25,1,2,1,3,6,'Серьги из золота 029038',_binary 'S395J7.jpg'),(8,'C635R4','Ожерелье','шт.',590000.00,10,2,1,3,2,16,'Ожерелье Lace (муассанит, круг, BS Regular, 6,5мм, 2 муассанит Кр-57 6мм',_binary 'C635R4.jpg'),(9,'F735H6','Серьги','шт.',12000.00,5,2,2,1,4,5,'Серьги из золота с эмалью',_binary 'F735H6.jpg'),(10,'S538J7','Серьги','шт.',2300.00,30,1,2,1,3,2,'Серьги с 4 фианитами из серебра с позолотой',_binary 'S538J7.jpg'),(11,'V835G5','Подвеска','шт.',695.00,10,1,1,2,3,6,'Подвеска из золочёного серебра с фианитами',''),(12,'P846H6','Подвеска','шт.',5195.00,5,2,2,2,3,6,'Подвеска из красного золота П142-4547',''),(13,'S530N6','Серьги','шт.',2900.00,15,1,1,1,2,16,'Серебряные серьги c ювелирной керамикой',''),(14,'N385N6','Серьги','шт.',6200.00,20,1,2,1,4,5,'Серьги-продевки из золота с фианитами',''),(15,'K943G6','Серьги','шт.',11545.00,25,2,2,1,3,2,'Серьги из золота с эмалью',''),(16,'S844B6','Подвеска','шт.',2100.00,6,2,1,2,3,6,'Подвеска из серебра с позолотой',''),(17,'B846B6','Браслет','шт.',5900.00,15,1,2,7,3,6,'Браслет из золота \"Бесконечность\" яхонт',''),(18,'L486B6','Серьги','шт.',7000.00,30,1,2,1,2,16,'Серьги из красного золота',''),(19,'H845N5','Серьги','шт.',2400.00,25,2,1,1,4,5,'Серьги из серебра с позолотой',''),(20,'F047G5','Брошь','шт.',7100.00,10,1,2,4,3,2,'Брошь PLATINA jewelry из серебра 925 пробы с эмалью',''),(21,'A485H6','Кольцо','шт.',1110.00,5,1,1,5,4,11,'Кольцо из серебра с позолотой',''),(22,'B845B6','Серьги','шт.',5200.00,30,2,2,1,3,6,'Серьги с фианитами и гематитами из серебра с позолотой',''),(23,'L596G5','Серьги','шт.',11000.00,15,2,1,1,3,6,'Серьги из красного золота',''),(24,'C453B6','Подвеска','шт.',5300.00,25,1,2,2,2,16,'Подвеска из красного золота',''),(25,'B835H6','Колье','шт.',2600.00,20,1,2,6,4,5,'Ювелирное колье из серебра 925 пробы с фианитами',''),(26,'P033N7','Подвеска','шт.',4300.00,5,1,1,2,3,2,'Подвеска из красного золота',''),(27,'B936H6','Колье','шт.',17500.00,5,2,2,6,3,9,'Колье Эстет Золотое колье',''),(28,'B964G6','Подвеска','шт.',5350.00,5,2,2,2,2,6,'Подвеска с 1 бриллиантом из красного золота',''),(29,'N764H5','Серьги','шт.',10600.00,10,1,1,1,4,3,'Платина Серьги из красного золота без камней',''),(30,'V494H6','Подвеска','шт.',480.00,15,1,2,2,2,12,'Подвеска серебряная с фианитами','');
/*!40000 ALTER TABLE `tovar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `iduser` int NOT NULL AUTO_INCREMENT,
  `id_role` int NOT NULL,
  `FIO` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`iduser`),
  KEY `id_role_idx` (`id_role`),
  CONSTRAINT `id_role` FOREIGN KEY (`id_role`) REFERENCES `Role` (`idRole`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'Савин Станислав Гордеевич','dlh4o1tzrbse@yahoo.com','2L6KZG'),(2,1,'Григорьева Есения Александровна','rdgm3tpai7ch@outlook.com','uzWC67'),(3,1,'Копылова Алиса Кирилловна','048anwxsgze1@outlook.com','8ntwUp'),(4,2,'Кузнецов Лев Фёдорович','9zg4lmtik3ja@yahoo.com','YOyhfR'),(5,2,'Иванов Михаил Тимофеевич','1p4khxif7awq@mail.com','RSbvHv'),(6,2,'Крюков Тимофей Ильич','zu56nc4l30xm@outlook.com','rwVDh9'),(7,3,'Игнатов Роман Степанович','iuf9onrqs1l4@mail.com','LdNyos'),(8,3,'Анисимова Алисия Сергеевна','hkonmlp8tdy2@mail.com','gynQMT'),(9,3,'Лебедева Софья Марковна','9ovm3eqak0jz@mail.com','AtnDjr'),(10,3,'Волков Богдан Денисович','5lfozwx7erq2@outlook.com','JlFRCZ'),(11,1,'1','1','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dem04.03.26'
--

--
-- Dumping routines for database 'dem04.03.26'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-04 14:15:39
